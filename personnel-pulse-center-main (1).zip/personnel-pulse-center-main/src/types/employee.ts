
export interface Employee {
  id: string;
  name: string;
  employmentType: 'Contractor' | 'Full-time' | 'Part-time';
  contactNumber: string;
  jobLocation: string;
  employeeId: string;
  jobTitle: string;
  dateOfJoining: string;
  address: Address;
  photoUrl?: string;
}

export interface Address {
  street: string;
  city: string;
  state: string;
  zipCode: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface AuthResponse {
  success: boolean;
  message?: string;
  employee?: Employee;
}

// Mock data for development
export const mockEmployees: Employee[] = [
  {
    id: '1',
    name: 'Giridhar Gharsan',
    employmentType: 'Contractor',
    contactNumber: '9099327322',
    jobLocation: 'USA',
    employeeId: 'CID2005',
    jobTitle: 'Product_Intern',
    dateOfJoining: '2024-08-15',
    address: {
      street: '4355 Fremont Blvd STE 214',
      city: 'Fremont',
      state: 'CA',
      zipCode: '94538'
    },
    photoUrl: ''
  }
];

export const mockCredentials = {
  'employee@company.com': {
    password: 'password123',
    employeeId: '1'
  }
};
