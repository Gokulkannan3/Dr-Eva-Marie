
import React, { useState, useEffect } from 'react';
import { MoreVertical, X, Play, Share2, UserPlus, ExternalLink } from 'lucide-react';
import '../styles/podcast/index.css';

// Updated podcast data with new images
const podcastData = [
  {
    id: 1,
    title: "The AI Revolution in Healthcare",
    description: "Exploring how artificial intelligence is transforming medical diagnosis, treatment, and patient care.",
    image: "public/lovable-uploads/46ff4d7f-5937-4110-8c95-ecd4c3269b35.png",
    background: "#0c472d",
    duration: "47:31",
    date: "Aug 14",
    publisher: "AI, Government, and the Future",
    link: "https://open.spotify.com/episode/6Tg3HdwgNSDiCrCvxuALNl?si=E2ZTL60ST3K9kSjreGmycQ"
  },
  {
    id: 2,
    title: "Out of the comfort zone - The Promise of Data and Digital",
    description: "If data, and going digital, are seen as the future in your business, then this is the interview for you.",
    image: "public/lovable-uploads/c1e7bbab-9550-43e3-956f-8e2684f6b564.png",
    background: "#9e0f2b",
    duration: "56:03",
    date: "Mar 20",
    publisher: "Out of the Comfort Zone",
    link: "https://open.spotify.com/episode/3ar4kGUeYQFVIFmQw7CYtn"
  },
  {
    id: 3,
    title: "Sustainable Tech: Building for Tomorrow",
    description: "A discussion on how technology companies are addressing climate change and environmental sustainability.",
    image: "public/lovable-uploads/4d32910e-5bd0-4116-ae8f-1c2f0826919c.png",
    background: "#505958",
    duration: "38:29",
    date: "Jan 23",
    publisher: "Hypewomen",
    link: "https://thehypewomen.com/dr-eva-marie-muller-stuler-is-ai-sexist"
  },
  {
    id: 4,
    title: "Ethical AI Development and Governance",
    description: "Exploring the frameworks and practices needed to ensure AI systems are developed responsibly.",
    image: "public/lovable-uploads/cad6bc6d-0104-476c-bd14-8ce35e6eba62.png",
    background: "#2c2c2c",
    duration: "25:38",
    date: "Aug 4",
    publisher: "Data Masters Podcast",
    link: "https://datamasterspodcast.com/e/68rm657n-ethical-ai-dr-evamarie-mullerstuler"
  },
  {
    id: 5,
    title: "Hyperwomen - Is AI sexist?",
    description: "In 2018 Amazon terminated its trial artificial intelligence (AI) recruiting tool after discovering it discriminated against women...",
    image: "public/lovable-uploads/46ff4d7f-5937-4110-8c95-ecd4c3269b35.png",
    background: "#1f1f1f",
    duration: "38:29",
    date: "Jan 23",
    publisher: "Hypewomen",
    link: "https://thehypewomen.com/dr-eva-marie-muller-stuler-is-ai-sexist"
  },
  {
    id: 6,
    title: "AI Ethics and the Future of Work",
    description: "An exploration of how AI is reshaping the workforce and the ethical considerations that come with this technological revolution.",
    image: "public/lovable-uploads/c1e7bbab-9550-43e3-956f-8e2684f6b564.png",
    background: "#0c472d",
    duration: "33:15",
    date: "Sep 2",
    publisher: "AI & Ethics",
    link: "https://open.spotify.com/episode/3B5weMKUIPclpNcE9yK2Ei"
  }
];

const PodcastCarousel = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [currentPodcast, setCurrentPodcast] = useState(null);
  const [progressValue, setProgressValue] = useState(10);
  
  const goToNextSlide = () => {
    setActiveIndex((prevIndex) => 
      prevIndex === podcastData.length - 1 ? 0 : prevIndex + 1
    );
  };
  
  const goToPrevSlide = () => {
    setActiveIndex((prevIndex) => 
      prevIndex === 0 ? podcastData.length - 1 : prevIndex - 1
    );
  };

  // Auto-slide functionality
  useEffect(() => {
    if (!isPlaying) {
      const interval = setInterval(() => {
        goToNextSlide();
      }, 5000);
      
      return () => clearInterval(interval);
    }
    return () => {};
  }, [isPlaying]);
  
  const getSlideClassName = (index) => {
    if (index === activeIndex) return "podcast-slide active";
    if (index === (activeIndex === 0 ? podcastData.length - 1 : activeIndex - 1)) return "podcast-slide prev";
    if (index === (activeIndex === podcastData.length - 1 ? 0 : activeIndex + 1)) return "podcast-slide next";
    return "podcast-slide";
  };

  const handleListenNowClick = (podcast) => {
    setCurrentPodcast(podcast);
    setIsPlaying(true);
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const handleMenuClick = (podcast, e) => {
    e.stopPropagation();
    setCurrentPodcast(podcast);
    setShowMenu(true);
  };

  const closeMenu = () => {
    setShowMenu(false);
  };

  const handlePlayOnSpotify = () => {
    window.open(currentPodcast.link, '_blank');
    setShowMenu(false);
  };

  const handleFollowOnSpotify = () => {
    window.open('https://open.spotify.com/show/0123456789', '_blank');
    setShowMenu(false);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(currentPodcast.link).then(() => {
      alert('Link copied to clipboard!');
      setShowMenu(false);
    });
  };

  return (
    <div className="podcast-carousel-container">      
      <div className="podcast-carousel">
        <button className="nav-button prev" onClick={goToPrevSlide}>
          <span className="nav-arrow">&#8249;</span>
        </button>
        
        <div className="podcast-slides">
          {podcastData.map((podcast, index) => (
            <div key={podcast.id} className={getSlideClassName(index)}>
              <div className="podcast-card">
                <div className="podcast-image-container">
                  <img 
                    src={podcast.image} 
                    alt={podcast.title} 
                    className="podcast-card-image"
                  />
                  <button 
                    className="podcast-menu-button"
                    onClick={(e) => handleMenuClick(podcast, e)}
                  >
                    <MoreVertical size={18} color="white" />
                  </button>
                </div>
                <div className="podcast-content">
                  <h2 className="podcast-title">{podcast.title}</h2>
                  <p className="podcast-description">{podcast.description}</p>
                  <button 
                    className="read-more-btn"
                    onClick={() => handleListenNowClick(podcast)}
                  >
                    Listen Now
                    <span className="arrow-icon">&#8250;</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <button className="nav-button next" onClick={goToNextSlide}>
          <span className="nav-arrow">&#8250;</span>
        </button>
      </div>

      {/* Spotify-style player */}
      {currentPodcast && isPlaying && (
        <div className="spotify-player" style={{ backgroundColor: currentPodcast.background }}>
          <div className="spotify-player-container">
            <div className="player-left">
              <img src={currentPodcast.image} alt={currentPodcast.title} className="player-thumbnail" />
            </div>
            <div className="player-center">
              <div className="player-title">{currentPodcast.title}</div>
              <div className="player-details">
                <span className="player-date">{currentPodcast.date}</span> • <span className="player-publisher">{currentPodcast.publisher}</span>
              </div>
              <div className="player-controls">
                <div className="player-progress">
                  <div className="player-time">15</div>
                  <div className="progress-bar-container">
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: `${progressValue}%` }}></div>
                    </div>
                  </div>
                  <div className="player-time">15</div>
                </div>
              </div>
            </div>
            <div className="player-right">
              <button className="player-save">
                <div className="save-icon">+</div>
                <span>Save on Spotify</span>
              </button>
              <div className="player-duration">{currentPodcast.duration}</div>
              <button className="player-menu" onClick={(e) => handleMenuClick(currentPodcast, e)}>
                <MoreVertical size={18} color="white" />
              </button>
              <button className="player-play-button" onClick={togglePlay}>
                <Play size={28} color="white" fill="white" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Spotify menu overlay */}
      {showMenu && currentPodcast && (
        <div className="spotify-menu-overlay">
          <div className="spotify-menu" style={{ backgroundColor: currentPodcast.background }}>
            <button className="menu-item" onClick={handlePlayOnSpotify}>
              <div className="menu-icon spotify-icon"></div>
              <span>Play on Spotify</span>
            </button>
            <button className="menu-item" onClick={handleFollowOnSpotify}>
              <div className="menu-icon follow-icon"></div>
              <span>Follow on Spotify</span>
            </button>
            <button className="menu-item" onClick={handleCopyLink}>
              <div className="menu-icon share-icon"></div>
              <span>Copy link</span>
            </button>
            <div className="menu-footer">
              <span>Privacy Policy • Terms & Conditions</span>
            </div>
            <button className="menu-close" onClick={closeMenu}>
              <X size={24} color="white" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PodcastCarousel;
