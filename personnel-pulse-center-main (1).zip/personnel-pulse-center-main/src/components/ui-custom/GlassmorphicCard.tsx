
import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface GlassmorphicCardProps {
  children: ReactNode;
  className?: string;
}

const GlassmorphicCard = ({ children, className }: GlassmorphicCardProps) => {
  return (
    <div 
      className={cn(
        "rounded-2xl bg-white/80 backdrop-blur-md border border-white/20 shadow-lg p-6",
        className
      )}
    >
      {children}
    </div>
  );
};

export default GlassmorphicCard;
