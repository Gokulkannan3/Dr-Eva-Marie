
import { ReactNode } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Home, LogOut, User } from "lucide-react";

interface AppLayoutProps {
  children: ReactNode;
}

const AppLayout = ({ children }: AppLayoutProps) => {
  const { isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  
  const handleLogout = () => {
    logout();
    navigate("/");
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      {isAuthenticated && (
        <header className="bg-white shadow-sm border-b border-gray-100 py-3 px-6">
          <div className="max-w-7xl mx-auto flex justify-between items-center">
            <Link to="/profile" className="flex items-center space-x-2 text-hrms-blue hover:text-hrms-blue-dark transition-colors">
              <Home className="w-5 h-5" />
              <span className="font-semibold">HRMS</span>
            </Link>
            
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                className="text-hrms-gray-dark hover:text-hrms-blue hover:bg-hrms-blue-light/10 transition-colors"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
              
              <Button 
                variant="outline" 
                className="border-hrms-blue text-hrms-blue hover:bg-hrms-blue-light/10 transition-colors"
              >
                <User className="w-4 h-4 mr-2" />
                Privileged User
              </Button>
            </div>
          </div>
        </header>
      )}
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          {children}
        </div>
      </main>
      
      <footer className="bg-white border-t border-gray-100 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-gray-500">
            © 2024 Infoway Solutions LLC. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default AppLayout;
