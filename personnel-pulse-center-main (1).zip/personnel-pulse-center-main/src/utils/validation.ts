
export const validateEmail = (email: string): { valid: boolean; message?: string } => {
  if (!email.trim()) {
    return { valid: false, message: "Email is required" };
  }
  
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(email)) {
    return { valid: false, message: "Please enter a valid email address" };
  }

  return { valid: true };
};

export const validatePassword = (password: string): { valid: boolean; message?: string } => {
  if (!password) {
    return { valid: false, message: "Password is required" };
  }
  
  if (password.length < 6) {
    return { valid: false, message: "Password must be at least 6 characters" };
  }

  return { valid: true };
};

export const validateImageFile = (file: File): { valid: boolean; message?: string } => {
  // Check file type
  const validTypes = ['image/jpeg', 'image/png', 'application/pdf'];
  if (!validTypes.includes(file.type)) {
    return { 
      valid: false, 
      message: "Invalid file format. Please upload a PDF, JPEG, or PNG file." 
    };
  }
  
  // Check file size (max 200KB = 200 * 1024 bytes)
  const maxSize = 200 * 1024;
  if (file.size > maxSize) {
    return { 
      valid: false, 
      message: "File size exceeds 200KB. Please upload a smaller file." 
    };
  }
  
  return { valid: true };
};
