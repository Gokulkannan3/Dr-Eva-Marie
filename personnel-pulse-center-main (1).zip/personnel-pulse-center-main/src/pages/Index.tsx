
import React from 'react';
import PodcastCarousel from '../components/PodcastCarousel';
import '../styles/IndexPage.css';

const Index = () => {
  return (
    <div className="index-page">
      <header className="site-header">
        <div className="logo">
          <h1>DrEVA.AI</h1>
        </div>
        <nav className="main-nav">
          <ul>
            <li><a href="#home">HOME</a></li>
            <li><a href="#about">ABOUT</a></li>
            <li><a href="#videos">VIDEOS</a></li>
            <li><a href="#publications">PUBLICATIONS</a></li>
            <li><a href="#podcasts" className="active">PODCASTS</a></li>
            <li><a href="#events">EVENTS</a></li>
          </ul>
        </nav>
      </header>

      <div className="hero-section">
        <h1>Explore our collection of podcasts on artificial intelligence, data science, and technology</h1>
        <div className="filter-tabs">
          <button className="filter-tab active">All</button>
          <button className="filter-tab">AI & Data</button>
          <button className="filter-tab">Ethics</button>
          <button className="filter-tab">Technology</button>
        </div>
      </div>

      <div className="podcast-section">
        <PodcastCarousel />
      </div>

      <footer className="site-footer">
        <p>© 2025 DrEVA.AI - All Rights Reserved.</p>
      </footer>
    </div>
  );
};

export default Index;
