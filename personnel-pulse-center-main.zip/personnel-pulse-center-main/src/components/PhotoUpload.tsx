
import { useState, useRef } from "react";
import { validateImageFile } from "@/utils/validation";
import { toast } from "@/utils/toast";
import { ImageIcon, Upload } from "lucide-react";
import { cn } from "@/lib/utils";

interface PhotoUploadProps {
  initialPhotoUrl?: string;
  onPhotoChange: (photoUrl: string) => void;
  className?: string;
}

const PhotoUpload = ({ initialPhotoUrl, onPhotoChange, className }: PhotoUploadProps) => {
  const [photoUrl, setPhotoUrl] = useState<string>(initialPhotoUrl || "");
  const [isHovered, setIsHovered] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    
    if (!file) {
      return;
    }
    
    const validation = validateImageFile(file);
    
    if (!validation.valid) {
      toast.error(validation.message);
      return;
    }
    
    const reader = new FileReader();
    
    reader.onload = (e) => {
      const newPhotoUrl = e.target?.result as string;
      setPhotoUrl(newPhotoUrl);
      onPhotoChange(newPhotoUrl);
      toast.success("Photo uploaded successfully");
    };
    
    reader.onerror = () => {
      toast.error("Error reading file");
    };
    
    reader.readAsDataURL(file);
  };

  return (
    <div 
      className={cn(
        "relative rounded-md overflow-hidden border border-gray-200 shadow-sm cursor-pointer transition-all duration-300 bg-white",
        className
      )}
      onClick={handlePhotoClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept=".pdf,.jpg,.jpeg,.png"
      />
      
      {photoUrl ? (
        <>
          <img 
            src={photoUrl} 
            alt="Employee" 
            className="w-full h-full object-cover"
          />
          {isHovered && (
            <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center animate-fade-in">
              <Upload className="w-6 h-6 text-white mb-2" />
              <span className="text-white text-sm">Replace Photo</span>
            </div>
          )}
        </>
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center p-6 bg-gray-50 text-gray-500">
          <ImageIcon className="w-8 h-8 mb-2" />
          <span className="text-sm font-medium">Click to upload image</span>
          <span className="text-xs mt-1 text-center">PDF, JPEG, PNG (Max: 200KB)</span>
        </div>
      )}
    </div>
  );
};

export default PhotoUpload;
