
import { useState, useEffect } from "react";
import { Address } from "@/types/employee";
import { Input } from "@/components/ui/input";

interface AddressFormProps {
  initialAddress: Address;
  onChange: (address: Address) => void;
}

const AddressForm = ({ initialAddress, onChange }: AddressFormProps) => {
  const [address, setAddress] = useState<Address>(initialAddress);

  useEffect(() => {
    setAddress(initialAddress);
  }, [initialAddress]);

  const handleChange = (field: keyof Address, value: string) => {
    const updatedAddress = { ...address, [field]: value };
    setAddress(updatedAddress);
    onChange(updatedAddress);
  };

  return (
    <div className="space-y-4">
      <div>
        <label htmlFor="street" className="form-label">Street Address</label>
        <Input
          id="street"
          value={address.street}
          onChange={(e) => handleChange("street", e.target.value)}
          className="input-field"
          placeholder="Street address"
        />
      </div>
      
      <div>
        <label htmlFor="city" className="form-label">City</label>
        <Input
          id="city"
          value={address.city}
          onChange={(e) => handleChange("city", e.target.value)}
          className="input-field"
          placeholder="City"
        />
      </div>
      
      <div>
        <label htmlFor="state" className="form-label">State</label>
        <Input
          id="state"
          value={address.state}
          onChange={(e) => handleChange("state", e.target.value)}
          className="input-field"
          placeholder="State"
        />
      </div>
      
      <div>
        <label htmlFor="zipCode" className="form-label">ZIP Code</label>
        <Input
          id="zipCode"
          value={address.zipCode}
          onChange={(e) => handleChange("zipCode", e.target.value)}
          className="input-field"
          placeholder="ZIP Code"
        />
      </div>
    </div>
  );
};

export default AddressForm;
