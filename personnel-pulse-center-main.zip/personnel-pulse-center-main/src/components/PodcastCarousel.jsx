
import React, { useState, useEffect } from 'react';
import '../styles/podcast/index.css';

// Updated podcast data with more relevant content and images
const podcastData = [
  {
    id: 1,
    title: "The AI Revolution in Healthcare",
    description: "Exploring how artificial intelligence is transforming medical diagnosis, treatment, and patient care.",
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=600&h=400",
    profileImage: "public/lovable-uploads/fe8130d5-2f0a-4339-90c9-35c289631afa.png"
  },
  {
    id: 2,
    title: "Out of the comfort zone - The Promise of Data and Digital",
    description: "If data, and going digital, are seen as the future in your business, then this is the interview for you. Whether the focus is on...",
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=600&h=400",
    profileImage: "public/lovable-uploads/577c7d0f-9d00-4d87-96d8-76c34d42322a.png"
  },
  {
    id: 3,
    title: "Sustainable Tech: Building for Tomorrow",
    description: "A discussion on how technology companies are addressing climate change and environmental sustainability.",
    image: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=600&h=400",
    profileImage: "public/lovable-uploads/8ab17391-68a8-478d-9d60-14539ac38e9e.png"
  },
  {
    id: 4,
    title: "Ethical AI Development and Governance",
    description: "Exploring the frameworks and practices needed to ensure AI systems are developed and deployed responsibly.",
    image: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=600&h=400",
    profileImage: "public/lovable-uploads/577c7d0f-9d00-4d87-96d8-76c34d42322a.png"
  },
  {
    id: 5,
    title: "Hyperwomen - Is AI sexist?",
    description: "In 2018 Amazon terminated its trial artificial intelligence (AI) recruiting tool after discovering it discriminated against women...",
    image: "https://images.unsplash.com/photo-1573164713988-8665fc963095?auto=format&fit=crop&w=600&h=400",
    profileImage: "public/lovable-uploads/577c7d0f-9d00-4d87-96d8-76c34d42322a.png"
  }
];

const PodcastCarousel = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  
  const goToNextSlide = () => {
    setActiveIndex((prevIndex) => 
      prevIndex === podcastData.length - 1 ? 0 : prevIndex + 1
    );
  };
  
  const goToPrevSlide = () => {
    setActiveIndex((prevIndex) => 
      prevIndex === 0 ? podcastData.length - 1 : prevIndex - 1
    );
  };

  // Auto-slide functionality
  useEffect(() => {
    const interval = setInterval(() => {
      goToNextSlide();
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);
  
  const getSlideClassName = (index) => {
    if (index === activeIndex) return "podcast-slide active";
    if (index === (activeIndex === 0 ? podcastData.length - 1 : activeIndex - 1)) return "podcast-slide prev";
    if (index === (activeIndex === podcastData.length - 1 ? 0 : activeIndex + 1)) return "podcast-slide next";
    return "podcast-slide";
  };

  return (
    <div className="podcast-carousel-container">      
      <div className="podcast-carousel">
        <button className="nav-button prev" onClick={goToPrevSlide}>
          <span className="nav-arrow">&#8249;</span>
        </button>
        
        <div className="podcast-slides">
          {podcastData.map((podcast, index) => (
            <div key={podcast.id} className={getSlideClassName(index)}>
              <div className="podcast-card">
                <div className="podcast-image-container">
                  <img 
                    src={podcast.image} 
                    alt={podcast.title} 
                    className="podcast-card-image"
                  />
                </div>
                <div className="podcast-content">
                  <h2 className="podcast-title">{podcast.title}</h2>
                  <p className="podcast-description">{podcast.description}</p>
                  <button className="read-more-btn">
                    Read More 
                    <span className="arrow-icon">&#8250;</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <button className="nav-button next" onClick={goToNextSlide}>
          <span className="nav-arrow">&#8250;</span>
        </button>
      </div>
    </div>
  );
};

export default PodcastCarousel;
