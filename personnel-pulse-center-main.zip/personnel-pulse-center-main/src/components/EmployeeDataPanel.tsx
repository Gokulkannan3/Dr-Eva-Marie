
import { useState, useEffect } from "react";
import { Employee, Address } from "@/types/employee";
import AddressForm from "@/components/AddressForm";
import PhotoUpload from "@/components/PhotoUpload";
import { Button } from "@/components/ui/button";
import { toast } from "@/utils/toast";
import { Save, X } from "lucide-react";

interface EmployeeDataPanelProps {
  employee: Employee;
  onSave: (updatedEmployee: Employee) => void;
}

const EmployeeDataPanel = ({ employee, onSave }: EmployeeDataPanelProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedEmployee, setEditedEmployee] = useState<Employee>(employee);
  const [originalEmployee, setOriginalEmployee] = useState<Employee>(employee);

  useEffect(() => {
    setEditedEmployee(employee);
    setOriginalEmployee(employee);
  }, [employee]);

  const handleAddressChange = (updatedAddress: Address) => {
    setEditedEmployee(prev => ({
      ...prev,
      address: updatedAddress
    }));
    setIsEditing(true);
  };

  const handlePhotoChange = (photoUrl: string) => {
    setEditedEmployee(prev => ({
      ...prev,
      photoUrl
    }));
    setIsEditing(true);
  };

  const handleSave = () => {
    onSave(editedEmployee);
    setOriginalEmployee(editedEmployee);
    setIsEditing(false);
    toast.success("Changes saved successfully");
  };

  const handleCancel = () => {
    setEditedEmployee(originalEmployee);
    setIsEditing(false);
    toast.info("Changes discarded");
  };

  const ReadOnlyField = ({ label, value }: { label: string; value: string }) => (
    <div className="mb-4">
      <h3 className="text-sm font-medium text-gray-500">{label}</h3>
      <p className="mt-1 text-base font-medium">{value}</p>
    </div>
  );

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-center text-hrms-blue-dark">View Employee Data</h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-4 animate-slide-up" style={{ animationDelay: "100ms" }}>
          <div className="bg-white/90 rounded-lg shadow-sm p-5 border border-gray-100">
            <ReadOnlyField label="Employee Name" value={employee.name} />
            <ReadOnlyField label="Employee ID" value={employee.employeeId} />
            <ReadOnlyField label="Employment Type" value={employee.employmentType} />
            <ReadOnlyField label="Job Title" value={employee.jobTitle} />
            <ReadOnlyField label="Date of Joining" value={employee.dateOfJoining} />
            <ReadOnlyField label="Contact Number" value={employee.contactNumber} />
            <ReadOnlyField label="Job Location" value={employee.jobLocation} />
          </div>
          
          <div className="bg-white/90 rounded-lg shadow-sm p-5 border border-gray-100">
            <h3 className="text-lg font-semibold mb-4 bg-hrms-blue text-white py-2 px-4 rounded-md">Address</h3>
            <AddressForm 
              initialAddress={editedEmployee.address} 
              onChange={handleAddressChange} 
            />
          </div>
        </div>
        
        <div className="animate-slide-up" style={{ animationDelay: "200ms" }}>
          <div className="bg-white/90 rounded-lg shadow-sm p-5 border border-gray-100 h-full flex flex-col">
            <h3 className="text-lg font-semibold mb-4 bg-hrms-blue text-white py-2 px-4 rounded-md">Photo</h3>
            <div className="flex-grow flex items-center justify-center">
              <PhotoUpload 
                initialPhotoUrl={editedEmployee.photoUrl} 
                onPhotoChange={handlePhotoChange}
                className="w-64 h-64"
              />
            </div>
          </div>
        </div>
      </div>
      
      {isEditing && (
        <div className="mt-8 flex justify-center space-x-4 animate-slide-up">
          <Button 
            onClick={handleSave} 
            className="bg-hrms-blue hover:bg-hrms-blue-dark transition-colors duration-300 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            Save
          </Button>
          
          <Button 
            onClick={handleCancel} 
            variant="outline"
            className="border-hrms-gray hover:bg-hrms-gray-light/50 transition-colors duration-300 flex items-center gap-2"
          >
            <X className="w-4 h-4" />
            Cancel
          </Button>
        </div>
      )}
    </div>
  );
};

export default EmployeeDataPanel;
