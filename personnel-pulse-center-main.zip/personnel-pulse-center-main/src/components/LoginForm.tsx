
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { validateEmail, validatePassword } from "@/utils/validation";
import GlassmorphicCard from "@/components/ui-custom/GlassmorphicCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Mail, Lock } from "lucide-react";

const LoginForm = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  
  const { login } = useAuth();
  const navigate = useNavigate();

  const validateForm = (): boolean => {
    let isValid = true;
    
    const emailValidation = validateEmail(email);
    if (!emailValidation.valid) {
      setEmailError(emailValidation.message || "");
      isValid = false;
    } else {
      setEmailError("");
    }
    
    const passwordValidation = validatePassword(password);
    if (!passwordValidation.valid) {
      setPasswordError(passwordValidation.message || "");
      isValid = false;
    } else {
      setPasswordError("");
    }
    
    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    
    try {
      const response = await login({ email, password });
      
      if (response.success) {
        navigate("/profile");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <GlassmorphicCard className="w-full max-w-md mx-auto animate-fade-in">
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-bold mb-2 text-hrms-blue-dark">HRMS</h1>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <label htmlFor="email" className="form-label flex items-center gap-2">
            <Mail className="w-4 h-4" />
            Email:
          </label>
          <Input
            id="email"
            type="email"
            placeholder="Your Email ID"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="input-field"
            disabled={isLoading}
          />
          {emailError && <p className="text-red-500 text-sm mt-1">{emailError}</p>}
        </div>
        
        <div className="space-y-2">
          <label htmlFor="password" className="form-label flex items-center gap-2">
            <Lock className="w-4 h-4" />
            Password:
          </label>
          <Input
            id="password"
            type="password"
            placeholder="Enter password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input-field"
            disabled={isLoading}
          />
          {passwordError && <p className="text-red-500 text-sm mt-1">{passwordError}</p>}
        </div>
        
        <Button 
          type="submit" 
          className="w-full bg-hrms-blue hover:bg-hrms-blue-dark transition-colors duration-300"
          disabled={isLoading}
        >
          {isLoading ? "Logging in..." : "Login"}
        </Button>
      </form>
      
      <div className="mt-6 text-center text-sm text-gray-500">
        * Use "employee@company.com" with password "password123" for demo
      </div>
    </GlassmorphicCard>
  );
};

export default LoginForm;
