import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import AppLayout from "@/layouts/AppLayout";
import EmployeeDataPanel from "@/components/EmployeeDataPanel";
import { Employee } from "@/types/employee";
import { toast } from "@/utils/toast";

const EmployeeProfile = () => {
  const { isAuthenticated, currentEmployee } = useAuth();
  const [employee, setEmployee] = useState<Employee | null>(null);
  const navigate = useNavigate();
  
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/");
      return;
    }
    
    setEmployee(currentEmployee);
  }, [isAuthenticated, currentEmployee, navigate]);
  
  const handleSaveEmployee = (updatedEmployee: Employee) => {
    setEmployee(updatedEmployee);
    
    // In a real app, this would make an API call to update the data
    localStorage.setItem("hrmsEmployee", JSON.stringify(updatedEmployee));
    
    // For demo purposes, let's add a small delay to simulate an API call
    setTimeout(() => {
      toast.success("Employee data updated successfully");
    }, 500);
  };
  
  if (!employee) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <p className="text-gray-500">Loading employee data...</p>
        </div>
      </AppLayout>
    );
  }
  
  return (
    <AppLayout>
      <EmployeeDataPanel 
        employee={employee} 
        onSave={handleSaveEmployee} 
      />
    </AppLayout>
  );
};

export default EmployeeProfile;
