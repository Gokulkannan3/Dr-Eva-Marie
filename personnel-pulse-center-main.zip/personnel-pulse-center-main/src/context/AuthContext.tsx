import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { Employee, mockCredentials, mockEmployees, LoginCredentials, AuthResponse } from "@/types/employee";
import { toast } from "@/utils/toast";

interface AuthContextType {
  currentEmployee: Employee | null;
  isAuthenticated: boolean;
  login: (credentials: LoginCredentials) => Promise<AuthResponse>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [currentEmployee, setCurrentEmployee] = useState<Employee | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const storedEmployeeData = localStorage.getItem("hrmsEmployee");
    if (storedEmployeeData) {
      try {
        const employee = JSON.parse(storedEmployeeData);
        setCurrentEmployee(employee);
        setIsAuthenticated(true);
      } catch (error) {
        console.error("Failed to parse stored employee data:", error);
        localStorage.removeItem("hrmsEmployee");
      }
    }
  }, []);

  const login = async (credentials: LoginCredentials): Promise<AuthResponse> => {
    await new Promise((resolve) => setTimeout(resolve, 800));

    const userCredentials = mockCredentials[credentials.email];
    if (!userCredentials) {
      toast.error("Incorrect email ID");
      return { success: false, message: "Incorrect email ID" };
    }

    if (userCredentials.password !== credentials.password) {
      toast.error("Incorrect password");
      return { success: false, message: "Incorrect password" };
    }

    const employee = mockEmployees.find(emp => emp.id === userCredentials.employeeId);
    if (!employee) {
      toast.error("Unauthorized user");
      return { success: false, message: "Unauthorized user" };
    }

    setCurrentEmployee(employee);
    setIsAuthenticated(true);
    
    localStorage.setItem("hrmsEmployee", JSON.stringify(employee));
    
    toast.success("Login successful!");
    return { 
      success: true, 
      employee 
    };
  };

  const logout = () => {
    setCurrentEmployee(null);
    setIsAuthenticated(false);
    localStorage.removeItem("hrmsEmployee");
    toast.info("Logged out successfully");
  };

  return (
    <AuthContext.Provider value={{ currentEmployee, isAuthenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
